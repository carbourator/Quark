# Trade-Entry-Quarkus

This project serves as an exploration of Quarkus, the Supersonic Subatomic Java Framework.

If you want to learn more about Quarkus, please visit its website: https://quarkus.io/ .

## Running the application in dev mode

You can run your application in dev mode directly from IDEA by navigating to Maven Tool Window (right sidebar), then 
Trade-Entry-Quarkus, plugins, quarkus and finally quarkus:dev

Alternatively you might want to look into command line options.

Quarkus CLI (more about it on https://quarkus.io/guides/cli-tooling) allows you to run app in dev mode using:
```shell script
quarkus dev
```

Bundled maven wrapper works like so:

```shell script
./mvnw compile quarkus:dev
```



## Running the application in dev mode

Application is now running and can be explored via swagger on http://localhost:8080/q/swagger-ui/.

There's two endpoints, one creates a mock Trade Entry, the other lists them.

The application uses a broker and a database. In dev mode, these are automatically provided and run in Docker/Podman
containers in a zero-config fashion. This is triggered by a detection of corresponding dependencies in the project pom file.
This functionality is called dev-services. More on it here: https://quarkus.io/guides/dev-services.

Database is filled automatically from import.sql file in resources folder.

Dev-services run components are accessible without any additional considerations, the ports are fixed in application.properties.
They can also be maintained as containers using standard Docker/Podman tools, such as ps command.
(Sidenote: I often found dev mode not terminating running containers when exiting via IDE, so they required manual
termination)

Dev-services might be disabled and the app in dev-mode can be configured to connect to any component running outside of
the dev-mode.
For example, our standard standalone localhost postgres database.

The downside of dev services is that they don't seem to be terribly powerful. I've found configuration and orchestration
capabilities to be lacking. For example it doesn't seem to be possible to run multiple brokers, which precludes their
utilization for Trade Entry. I suspect more problems would be discovered down the road.


> **_NOTE:_**  Quarkus comes with a Dev UI, which is available in dev mode only at http://localhost:8080/q/dev/.

## Live coding

This is the killer feature. Dev mode enables hot deployment with background compilation. When you modify your files
(in IDE for example) the modification is detected and the subsequent request triggers background compilation and deployment.
This should also be available for "remote" development, outside of the dev-mode, in a setup such as OpenShift.

## About CDI

The core of the Quarkus framework is ArC - CDI implementation based on the Jakarta CDI. In fact it is an implementation
of a trimmed down CDI Lite specification, which forgoes some CDI full functionality in exchange for performance. In my 
experience, this doesn't cause any problems/discomfort as not much functionality was removed.
More on it here: 
https://www.theserverside.com/blog/Coffee-Talk-Java-News-Stories-and-Opinions/CDI-Full-vs-CDI-Lite-What-changed-in-Contexts-and-Dependency-Injection-40

The crux of any dependency injection is the lifecycle management and injection of components - beans - by a container. 
We currently use Jakarta CDI on Trade Entry and while there would be some slight difference, migration to Quarkus would 
probably be pretty straightforward. Both frameworks share basic structure (and specification) so this means the application
is build around beans using 5 basic scopes (actually one is a pseudo-scope): Singleton, Application, Session, Request
and Dependent

More on this here: https://quarkus.io/guides/cdi


## Miscellaneous business

Quarkus comes with its own Hibernate ORM solution: Panache. This allows, apart from the repository pattern, also active 
report patter to handle data access and manipulation.
This means that operations are invoked on the entity class/object, rather than via dedicated DAO object. 

See 

te.persist();

in TradeEntryResource.


More at: https://quarkus.io/guides/hibernate-orm-panache

Quarkus also offers many features facilitating reactive programming paradigm. 
In this paradigm, threads are not blocked when waiting for the result of an I/O.
This allows low number of OS threads to manage many concurrent I/Os and as a result, higher concurrency, less memory usage,
and improved deployment density.
Endpoints, REST clients and database clients could be re-implemented using this paradigm.
More on this here:
https://quarkus.io/guides/quarkus-reactive-architecture
https://quarkus.io/guides/getting-started-reactive


## Miscellaneous other

Newer Quarkus versions require Java 17 at minimum. 
Conservative upgrading of DBG could clash with the faster one of Quarkus.
This project uses the last Java 11 supported version. 


https://quarkus.io/blog/java-17/



## Packaging and running the application

The application can be packaged using:
```shell script
./mvnw package
```
It produces the `quarkus-run.jar` file in the `target/quarkus-app/` directory.
Be aware that it’s not an _über-jar_ as the dependencies are copied into the `target/quarkus-app/lib/` directory.

The application is now runnable using `java -jar target/quarkus-app/quarkus-run.jar`.

If you want to build an _über-jar_, execute the following command:
```shell script
./mvnw package -Dquarkus.package.type=uber-jar
```

The application, packaged as an _über-jar_, is now runnable using `java -jar target/*-runner.jar`.

## Creating a native executable

You can create a native executable using: 
```shell script
./mvnw package -Dnative
```

Or, if you don't have GraalVM installed, you can run the native executable build in a container using: 
```shell script
./mvnw package -Dnative -Dquarkus.native.container-build=true
```

You can then execute your native executable with: `./target/Trade-Entry-Quarkus-1.0.0-SNAPSHOT-runner`

If you want to learn more about building native executables, please consult https://quarkus.io/guides/maven-tooling.

