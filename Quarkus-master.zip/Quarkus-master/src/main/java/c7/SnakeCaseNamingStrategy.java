package c7;


import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;


public class SnakeCaseNamingStrategy extends PhysicalNamingStrategyStandardImpl {

    public static final long serialVersionUID = 42L;

    public Identifier toPhysicalTableName(Identifier name, JdbcEnvironment context) {
        String translation = convertCamelToSnake(name.getText());
        return new Identifier(translation, name.isQuoted());
    }

    public Identifier toPhysicalColumnName(Identifier name, JdbcEnvironment context) {
        String translation = convertCamelToSnake(name.getText());
        return new Identifier(translation, name.isQuoted());
    }

    private String convertCamelToSnake(String input) {
        // Convert CamelCase to snake_case
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);
            if (Character.isUpperCase(currentChar)) {
                if (i > 0) {
                    result.append('_');
                }
                result.append(Character.toLowerCase(currentChar));
            } else {
                result.append(currentChar);
            }
        }
        return result.toString();
    }
}