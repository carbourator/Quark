package c7;

import c7.entities.TradeEntry;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;

import java.util.List;

@ApplicationScoped
public class TradeEntryRepository implements PanacheRepository<TradeEntry> {


    public List<TradeEntry> getAllTrades(){
        return listAll();
    }


}
