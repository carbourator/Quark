package c7.amqp;

import c7.configuration.Configuration;
import c7.entities.TradeEntry;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Provider;
import jakarta.jms.*;

import org.apache.commons.lang3.text.StrSubstitutor;
import org.apache.qpid.jms.JmsConnection;

import javax.naming.NamingException;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@ApplicationScoped
public class AMQPClient {


    @Configuration( "tig.broker")
    private Provider<String> broker;

    @Configuration( "tig.queue")
    private  Provider<String> queue;

    @Configuration( "tig.maxRetry")
    private  Provider<String> maxRetry ;
    @Configuration( "tig.timeInterval")
    private  Provider<String> timeInterval;
    @Configuration( "tig.userName")
    private  Provider<String> userName;
    @Configuration( "tig.password")
    private  Provider<String> password;



    private volatile Connection connection;




    public final synchronized void establishConnection() {
        if (!isConnected()) try { // double-check idiom
            ConnectionFactory connectionFactory = JMSFactory.getConnectionFactory(this.broker.get(), this.timeInterval.get(), this.maxRetry.get());
            this.connection = connectionFactory.createConnection(this.userName.get(), this.password.get());
            this.connection.start();
        } catch (Exception e) {
            System.out.println("AMQP connection fail");
        }
    }

    public void send(String payload, TradeEntry queueName) throws JMSException {
        this.send(payload, dynamicQueueName(queueName), setMessagePropertiesCallback -> {});
    }

    public void send(String payload, String queueName, MessageCallback setMessagePropertiesCallback) throws JMSException {
        if (ensureConnection()) {
            try (Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE)) {
                TextMessage message = session.createTextMessage();
                setMessagePropertiesCallback.perform(message);
                message.setText(payload);
                message.setJMSType(routingKey(queueName));
                try(MessageProducer producer = session.createProducer(JMSFactory.getDestination(exchange(queueName)))) {
                    producer.send(message);
                }
            } catch (NamingException e) {
                JMSException jmsException = new JMSException("Failed to locate destination "+exchange(queueName));
                jmsException.initCause(e);
                throw jmsException;
            } catch (JMSException e) {
                this.close();
                throw e;
            }
        }else {
            throw new JMSException("AMQP connection not established");
        }
    }

    public void send(byte[] payload, String queueName) throws JMSException {
        if (ensureConnection()) {
            try (Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE)) {
                BytesMessage message = session.createBytesMessage();
                message.writeBytes(payload);
                message.setJMSType(routingKey(queueName));
                try(MessageProducer producer = session.createProducer(JMSFactory.getDestination(exchange(queueName)))) {
                    producer.send(message);
                }
            } catch (NamingException e) {
                JMSException jmsException = new JMSException("Failed to locate destination "+exchange(queueName));
                jmsException.initCause(e);
                throw jmsException;
            } catch (JMSException e) {
                this.close();
                throw e;
            }
        }else {
            throw new JMSException("AMQP connection not established");
        }
    }

    private String routingKey(String queueName) {
        return queueName.substring(queueName.indexOf("/")+1);
    }

    private String exchange(String queueName) {
        return queueName.contains("/") ? queueName.substring(0, queueName.indexOf("/")) : queueName;
    }

    public synchronized boolean ensureConnection(){
        if (!isConnected()){
            establishConnection();
        }
        return isConnected();
    }

    public int hash() {
        return hash( this.broker.get(), this.maxRetry.get(), this.timeInterval.get(), this.userName.get(), this.password.get());
    }

    public static int hash(String broker, String maxRetry, String timeInterval, String userName,
                           String password) {
        return Objects.hash(broker, maxRetry, timeInterval, userName, password);
    }

    private synchronized boolean isConnected() {
        return this.connection != null && ((JmsConnection)this.connection).isConnected();
    }

    public synchronized void close() {
        if(this.connection!= null) {
            try {
                this.connection.close();
            } catch (JMSException e) {
                System.out.println("Error closing");
            }
        }
    }

    public interface MessageCallback {

        void perform(TextMessage message) throws JMSException;

    }

    private String dynamicQueueName(TradeEntry tradeEntry) {
        Map<String, String> map = new HashMap<>();
        map.put("Prefix",queue.get());    // queue is in format exchange/routing-key-prefix
        map.put("SecuID",tradeEntry.getProductSymbol());
        map.put("ApplID","C7TE");
        map.put("PartNo","1");
        map.put("ApplSeqNum", tradeEntry.getId().toString());
        map.put("MultiMessageNo", tradeEntry.getId().toString());
        map.put("TrdDat", tradeEntry.getBusinessDate().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
        String queueName = StrSubstitutor.replace("${Prefix}.${SecuID}.${ApplID}.${PartNo}.${ApplSeqNum}.${MultiMessageNo}.${TrdDat}", map);
        return queueName;
    }

}
