package c7.amqp;

import jakarta.jms.ConnectionFactory;
import jakarta.jms.Destination;
import jakarta.jms.JMSException;
import org.apache.commons.lang3.text.StrSubstitutor;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

class JMSFactory {

    static ConnectionFactory getConnectionFactory(String broker, String timeInterval,
                                                  String maxRetry)
            throws NamingException, JMSException {
        Properties properties = new Properties();

        properties.setProperty(Context.INITIAL_CONTEXT_FACTORY,
                "org.apache.qpid.jms.jndi.JmsInitialContextFactory");

        Map<String, String> connectionParameters = new HashMap<>();
        connectionParameters.put("broker", broker);
        connectionParameters.put("timeInterval", timeInterval);
        connectionParameters.put("maxRetry", maxRetry);

        properties.setProperty("connectionfactory.connection",
                StrSubstitutor.replace("failover:(amqp://${broker})"
                                + "?failover.initialReconnectDelay=${timeInterval}"
                                + "&failover.reconnectDelay=${timeInterval}"
                                + "&failover.maxReconnectAttempts=${maxRetry}"
                                + "&failover.useReconnectBackOff=false"
                                + "&failover.nested.amqp.saslMechanisms=PLAIN"
                                + "&failover.nested.amqp.idleTimeout=30000",
                        connectionParameters));

        return (ConnectionFactory) new InitialContext(properties).lookup("connection");
    }

    static Destination getDestination(String exchange) throws NamingException {
        Properties properties = new Properties();
        properties.setProperty(Context.INITIAL_CONTEXT_FACTORY,
                "org.apache.qpid.jms.jndi.JmsInitialContextFactory");
        properties.setProperty("topic.queueAddress", exchange);
        return (Destination) new InitialContext(properties).lookup("queueAddress");
    }
}

