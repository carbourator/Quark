package c7.configuration;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.Dependent;
import jakarta.enterprise.inject.Produces;
import jakarta.enterprise.inject.spi.InjectionPoint;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@ApplicationScoped
public class ConfigurationFactory {

    @PersistenceContext
    EntityManager entityManager;



    @Produces
    @Dependent
    @Configuration
    String readConfigurationString(InjectionPoint injectionPoint) {
        Configuration tag = injectionPoint.getAnnotated().getAnnotation(Configuration.class);
        try {
            return entityManager.createQuery("select value from Configuration where tag = :tag",String.class)
                    .setParameter("tag",tag.value())
                    .getSingleResult();
        } catch (Exception e) {
            System.err.println("Cannot read configuration for tag " + tag.value());
            throw e;
        }
    }

    @Produces @Dependent
    @Configuration
    Integer readConfigurationInteger(InjectionPoint injectionPoint) {
        return Integer.valueOf(this.readConfigurationString(injectionPoint));
    }

    @Produces @Dependent
    @Configuration
    Boolean readConfigurationBoolean(InjectionPoint injectionPoint) {
        return Boolean.parseBoolean(this.readConfigurationString(injectionPoint));
    }
}

