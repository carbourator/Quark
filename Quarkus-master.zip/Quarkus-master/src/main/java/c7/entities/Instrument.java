package c7.entities;

import c7.rest.TradeEntryRequest;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import java.math.BigDecimal;

public class Instrument {

    @Schema(description = "Instrument product symbol",
            example = "ODAX")
    private String productSymbol;
//    @Schema(description = "Instrument strike price", type= SchemaType.STRING,
//            example = "5000.0")
    private BigDecimal strikePrice;
    @Schema(description = "Instrument Put/Call",
            example = "C")
    private TradeEntryRequest.ClassCodeEnum putCall;
    @Schema(description = "Instrument maturity",
            example = "201912")
    private String maturity;
    @Schema(description = "Instrument contract date",
            example = "2014-02-28")
    private String contractDate;
    @Schema(description = "Instrument expiration date",
            example = "2014-02-28")
    private String expirationDate;



    public String getProductSymbol() {
        return productSymbol;
    }

    public void setProductSymbol(String productSymbol) {
        this.productSymbol = productSymbol;
    }

    public BigDecimal getStrikePrice() {
        return strikePrice;
    }

    public void setStrikePrice(BigDecimal strikePrice) {
        this.strikePrice = strikePrice;
    }

    public TradeEntryRequest.ClassCodeEnum getPutCall() {
        return putCall;
    }

    public void setPutCall(TradeEntryRequest.ClassCodeEnum putCall) {
        this.putCall = putCall;
    }

    public String getMaturity() {
        return maturity;
    }

    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

    public String getContractDate() {
        return contractDate;
    }

    public void setContractDate(String contractDate) {
        this.contractDate = contractDate;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }
}

