package c7.entities;

import c7.rest.TradeEntryRequest;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

public class Side{


    @Schema(description = "Sponsor",
            example = "CBKFR")
    private String sponsor;
    @Schema(description = "Owner",
            example = "CBKFR")
    private String owner;
    @Schema(description = "Account name",
            example = "A1")
    private String accountName;
    @Schema(description = "Open/Close indicator",
            example = "C")
    private TradeEntryRequest.OpenCloseIndicatorEnum openCloseIndicator;
    @Schema(description = "Trade id",
            example = "125")
    private String tradeId;
    @Schema(description = "Optional text 1",
            example = "text 1")
    private String text1;
    @Schema(description = "Optional text 1",
            example = "text 2")
    private String text2;
    @Schema(description = "Optional text 1",
            example = "text 3")
    private String text3;
    @Schema(description = "Trader id",
            example = "TRD001")
    private String traderId;
    @Schema(description = "Quantity",
            example = "1")
    private Integer quantity;
    @Schema(description = "Own reference id",
            example = "reference")
    private String ownReferenceId;
    @Schema(description = "Custom order handling instruction",
            example = "instruction")
    private String custOrdHdlInst;

    public String getSponsor() {
        return sponsor;
    }

    public void setSponsor(String sponsor) {
        this.sponsor = sponsor;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public TradeEntryRequest.OpenCloseIndicatorEnum getOpenCloseIndicator() {
        return openCloseIndicator;
    }

    public void setOpenCloseIndicator(
            TradeEntryRequest.OpenCloseIndicatorEnum openCloseIndicator) {
        this.openCloseIndicator = openCloseIndicator;
    }

    public String getTradeId() {
        return tradeId;
    }

    public void setTradeId(String tradeId) {
        this.tradeId = tradeId;
    }

    public String getText1() {
        return text1;
    }

    public void setText1(String text1) {
        this.text1 = text1;
    }

    public String getText2() {
        return text2;
    }

    public void setText2(String text2) {
        this.text2 = text2;
    }

    public String getText3() {
        return text3;
    }

    public void setText3(String text3) {
        this.text3 = text3;
    }

    public String getTraderId() {
        return this.traderId;
    }

    public void setTraderId(String traderId) {
        this.traderId = traderId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getOwnReferenceId() {
        return ownReferenceId;
    }

    public void setOwnReferenceId(String ownReferenceId) {
        this.ownReferenceId = ownReferenceId;
    }

    public String getCustOrdHdlInst() {
        return custOrdHdlInst;
    }

    public void setCustOrdHdlInst(String custOrdHdlInst) {
        this.custOrdHdlInst = custOrdHdlInst;
    }
}
