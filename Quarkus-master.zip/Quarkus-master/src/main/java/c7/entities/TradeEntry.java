package c7.entities;


import io.quarkus.hibernate.orm.panache.PanacheEntity;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
public class TradeEntry  extends PanacheEntityBase {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(columnDefinition = "varchar")
    private String tradeMatchReport;

    private LocalDate businessDate;


    public String getTradeMatchReport() {
        return tradeMatchReport;
    }

    public void setTradeMatchReport(String tradeMatchReport) {
        this.tradeMatchReport = tradeMatchReport;
    }

    public LocalDate getBusinessDate() {
        return businessDate;
    }

    public void setBusinessDate(LocalDate businessDate) {
        this.businessDate = businessDate;
    }


    private LocalDateTime insertTime;
    private Long maintenanceEventId;
    private String clearingHouse;
    private String enteringUser;

    private String enteringParticipant;
    private String market;
    @Column(precision=27, scale=10)
    private BigDecimal price;

    private String basketId;
    private String buyerSymbol;
    private String buyerSponsor;
    private String buyerAccountName;
    @Enumerated(EnumType.STRING)
    private OpenCloseIndicatorEnum buyerOpenCloseIndicator;
    private String buyerTradeId;
    private String buyerTraderId;

    private Integer buyerQuantity;

    private String buyerText1;
    private String buyerText2;
    private String buyerText3;
    private String buyerOwnReferenceId;
    private String buyerCustOrdHdlInst;
    private String sellerSymbol;
    private String sellerAccountName;
    private String sellerSponsor;
    @Enumerated(EnumType.STRING)
    private OpenCloseIndicatorEnum sellerOpenCloseIndicator;
    private Integer sellerQuantity;
    private String sellerText1;
    private String sellerText2;
    private String sellerText3;
    private String sellerTraderId;
    private String sellerTradeId;
    private String sellerOwnReferenceId;
    private String sellerCustOrdHdlInst;

    private String productSymbol;
    @Enumerated(EnumType.STRING)
    private ClassCodeEnum putCall;
    @Enumerated(EnumType.ORDINAL)
    private TradeTypeEnum tradeType;
    private String maturity;
    private String contractDate;
    private String expirationDate;
    private BigDecimal strikePrice;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMaintenanceEventId() {
        return maintenanceEventId;
    }

    public void setMaintenanceEventId(Long maintenanceEventId) {
        this.maintenanceEventId = maintenanceEventId;
    }


    public String getEnteringUser() {
        return enteringUser;
    }

    public void setEnteringUser(String enteringUser) {
        this.enteringUser = enteringUser;
    }

    public String getEnteringParticipant() {
        return enteringParticipant;
    }

    public void setEnteringParticipant(String registeredParticipant) {
        this.enteringParticipant = registeredParticipant;
    }

    public String getClearingHouse() {
        return clearingHouse;
    }

    public void setClearingHouse(String clearingHouse) {
        this.clearingHouse = clearingHouse;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getBuyerSymbol() {
        return buyerSymbol;
    }

    public void setBuyerSymbol(String buyerSymbol) {
        this.buyerSymbol = buyerSymbol;
    }

    public String getBuyerAccountName() {
        return buyerAccountName;
    }

    public void setBuyerAccountName(String accountName) {
        this.buyerAccountName = accountName;
    }

    public OpenCloseIndicatorEnum getBuyerOpenCloseIndicator() {
        return buyerOpenCloseIndicator;
    }

    public void setBuyerOpenCloseIndicator(OpenCloseIndicatorEnum openCloseIndicator) {
        this.buyerOpenCloseIndicator = openCloseIndicator;
    }

    public Integer getBuyerQuantity() {
        return buyerQuantity;
    }

    public void setBuyerQuantity(Integer quantity) {
        this.buyerQuantity = quantity;
    }

    public String getBuyerText1() {
        return buyerText1;
    }

    public void setBuyerText1(String text1) {
        this.buyerText1 = text1;
    }

    public String getBuyerText2() {
        return buyerText2;
    }

    public void setBuyerText2(String text2) {
        this.buyerText2 = text2;
    }

    public String getBuyerText3() {
        return buyerText3;
    }

    public void setBuyerText3(String text3) {
        this.buyerText3 = text3;
    }

    public String getBuyerSponsor() {
        return buyerSponsor;
    }

    public void setBuyerSponsor(String sponsor) {
        this.buyerSponsor = sponsor;
    }

    public String getBuyerTraderId() {
        return buyerTraderId;
    }

    public void setBuyerTraderId(String traderId) {
        this.buyerTraderId = traderId;
    }

    public String getBuyerTradeId() {
        return buyerTradeId;
    }

    public void setBuyerTradeId(String tradeId) {
        this.buyerTradeId = tradeId;
    }

    public String getSellerSymbol() {
        return sellerSymbol;
    }

    public void setSellerSymbol(String sellerSymbol) {
        this.sellerSymbol = sellerSymbol;
    }

    public String getSellerAccountName() {
        return sellerAccountName;
    }

    public void setSellerAccountName(String accountName) {
        this.sellerAccountName = accountName;
    }

    public OpenCloseIndicatorEnum getSellerOpenCloseIndicator() {
        return sellerOpenCloseIndicator;
    }

    public void setSellerOpenCloseIndicator(OpenCloseIndicatorEnum openCloseIndicator) {
        this.sellerOpenCloseIndicator = openCloseIndicator;
    }

    public Integer getSellerQuantity() {
        return sellerQuantity;
    }

    public void setSellerQuantity(Integer quantity) {
        this.sellerQuantity = quantity;
    }

    public String getSellerText1() {
        return sellerText1;
    }

    public void setSellerText1(String text1) {
        this.sellerText1 = text1;
    }

    public String getSellerText2() {
        return sellerText2;
    }

    public void setSellerText2(String text2) {
        this.sellerText2 = text2;
    }

    public String getSellerText3() {
        return sellerText3;
    }

    public void setSellerText3(String text3) {
        this.sellerText3 = text3;
    }

    public String getSellerSponsor() {
        return sellerSponsor;
    }

    public void setSellerSponsor(String sponsor) {
        this.sellerSponsor = sponsor;
    }

    public String getSellerTraderId() {
        return sellerTraderId;
    }

    public void setSellerTraderId(String traderId) {
        this.sellerTraderId = traderId;
    }

    public String getSellerTradeId() {
        return sellerTradeId;
    }

    public void setSellerTradeId(String tradeId) {
        this.sellerTradeId = tradeId;
    }

    public String getProductSymbol() {
        return productSymbol;
    }

    public void setProductSymbol(String productSymbol) {
        this.productSymbol = productSymbol;
    }

    public ClassCodeEnum getPutCall() {
        return putCall;
    }

    public void setPutCall(ClassCodeEnum putCall) {
        this.putCall = putCall;
    }

    public BigDecimal getStrikePrice() {
        return strikePrice;
    }

    public void setStrikePrice(BigDecimal strikePrice) {
        this.strikePrice = strikePrice;
    }

    public String getMaturity() {
        return maturity;
    }

    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

    public String getContractDate() {
        return contractDate;
    }

    public void setContractDate(String contractDate) {
        this.contractDate = contractDate;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public LocalDateTime getInsertTime() {
        return insertTime;
    }

    public void setInsertTime(LocalDateTime insertTime) {
        this.insertTime = insertTime;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public TradeTypeEnum getTradeType() {
        return tradeType;
    }

    public void setTradeType(TradeTypeEnum tradeType) {
        this.tradeType = tradeType;
    }

    public String getBasketId() {
        return basketId;
    }

    public void setBasketId(String basketId) {
        this.basketId = basketId;
    }

    public String getBuyerOwnReferenceId() {
        return buyerOwnReferenceId;
    }

    public void setBuyerOwnReferenceId(String buyerOwnReferenceId) {
        this.buyerOwnReferenceId = buyerOwnReferenceId;
    }

    public String getSellerOwnReferenceId() {
        return sellerOwnReferenceId;
    }

    public void setSellerOwnReferenceId(String sellerOwnReferenceId) {
        this.sellerOwnReferenceId = sellerOwnReferenceId;
    }

    public String getBuyerCustOrdHdlInst() {
        return buyerCustOrdHdlInst;
    }

    public void setBuyerCustOrdHdlInst(String buyerCustOrdHdlInst) {
        this.buyerCustOrdHdlInst = buyerCustOrdHdlInst;
    }

    public String getSellerCustOrdHdlInst() {
        return sellerCustOrdHdlInst;
    }

    public void setSellerCustOrdHdlInst(String sellerCustOrdHdlInst) {
        this.sellerCustOrdHdlInst = sellerCustOrdHdlInst;
    }


    @Override
    public String toString() {
        return "TradeEntry{" +
                "id=" + id +
                ", tradeMatchReport='" + tradeMatchReport + '\'' +
                ", businessDate=" + businessDate +
                ", insertTime=" + insertTime +
                ", maintenanceEventId=" + maintenanceEventId +
                ", clearingHouse='" + clearingHouse + '\'' +
                ", enteringUser='" + enteringUser + '\'' +
                ", enteringParticipant='" + enteringParticipant + '\'' +
                ", market='" + market + '\'' +
                ", price=" + price +
                ", basketId='" + basketId + '\'' +
                ", buyerSymbol='" + buyerSymbol + '\'' +
                ", buyerSponsor='" + buyerSponsor + '\'' +
                ", buyerAccountName='" + buyerAccountName + '\'' +
                ", buyerOpenCloseIndicator=" + buyerOpenCloseIndicator +
                ", buyerTradeId='" + buyerTradeId + '\'' +
                ", buyerTraderId='" + buyerTraderId + '\'' +
                ", buyerQuantity=" + buyerQuantity +
                ", buyerText1='" + buyerText1 + '\'' +
                ", buyerText2='" + buyerText2 + '\'' +
                ", buyerText3='" + buyerText3 + '\'' +
                ", buyerOwnReferenceId='" + buyerOwnReferenceId + '\'' +
                ", buyerCustOrdHdlInst='" + buyerCustOrdHdlInst + '\'' +
                ", sellerSymbol='" + sellerSymbol + '\'' +
                ", sellerAccountName='" + sellerAccountName + '\'' +
                ", sellerSponsor='" + sellerSponsor + '\'' +
                ", sellerOpenCloseIndicator=" + sellerOpenCloseIndicator +
                ", sellerQuantity=" + sellerQuantity +
                ", sellerText1='" + sellerText1 + '\'' +
                ", sellerText2='" + sellerText2 + '\'' +
                ", sellerText3='" + sellerText3 + '\'' +
                ", sellerTraderId='" + sellerTraderId + '\'' +
                ", sellerTradeId='" + sellerTradeId + '\'' +
                ", sellerOwnReferenceId='" + sellerOwnReferenceId + '\'' +
                ", sellerCustOrdHdlInst='" + sellerCustOrdHdlInst + '\'' +
                ", productSymbol='" + productSymbol + '\'' +
                ", putCall=" + putCall +
                ", tradeType=" + tradeType +
                ", maturity='" + maturity + '\'' +
                ", contractDate='" + contractDate + '\'' +
                ", expirationDate='" + expirationDate + '\'' +
                ", strikePrice=" + strikePrice +
                "}\n\n";
    }

    public enum OpenCloseIndicatorEnum {
        O, C;

        public static <T extends Enum> OpenCloseIndicatorEnum valueOf(T otherValue) {
            return otherValue != null ? valueOf(otherValue.name()) : null;
        }
    }

    public enum ClassCodeEnum {
        P("0"), C("1");

        private String value;

        ClassCodeEnum(String value) {
            this.value = value;
        }

        public static <T extends Enum> ClassCodeEnum valueOf(T otherValue) {
            return otherValue != null ? valueOf(otherValue.name()) : null;
        }

        public String getValue() {
            return this.value;
        }
    }

    public enum TradeTypeEnum {

        ON_EXCHANGE_TRADE, OTC_TRADE

    }

}

