package c7.entitlement;

import jakarta.annotation.Priority;
import jakarta.interceptor.AroundInvoke;
import jakarta.interceptor.Interceptor;
import jakarta.interceptor.InvocationContext;

@Interceptor
@Entitled
@Priority(Interceptor.Priority.APPLICATION + 10)
public class EntitlementInterceptor {



    @AroundInvoke
    public Object intercept(final InvocationContext invocationContext) {

        try {
            return invocationContext.proceed();
        } catch (Exception e) {
            return null;
        }
    }

}