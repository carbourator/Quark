package c7.rest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import java.util.List;

@Schema(name = TradeEntryRequest.PUBLIC_INTERFACE_TYPE_NAME)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TradeEntryRequest {

    public static final String PUBLIC_INTERFACE_TYPE_NAME = "TradeEntryRequest";

    @Schema(description = "Trade entry clearinghouse symbol", example = "ECAG")
    private String clearingHouseSymbol;

    @Schema(description = "Trade entry registered participant", example = "ECAG")
    private String registeredParticipant;

    @Schema(description = "Trade entry userId", example = "EUREXCLR123")
    private String userId;

    private List<TradeRequestDetail> trades;

    public String getClearingHouseSymbol() {
        return clearingHouseSymbol;
    }

    public void setClearingHouseSymbol(String clearingHouseSymbol) {
        this.clearingHouseSymbol = clearingHouseSymbol;
    }

    public String getRegisteredParticipant() {
        return registeredParticipant;
    }

    public void setRegisteredParticipant(String registeredParticipant) {
        this.registeredParticipant = registeredParticipant;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<TradeRequestDetail> getTrades() {
        return trades;
    }

    public void setTrades(List<TradeRequestDetail> trades) {
        this.trades = trades;
    }

    public enum ClassCodeEnum {
        P,C;
    }

    public enum OpenCloseIndicatorEnum {
        O,C;
    }


    }
