package c7.rest;

import c7.TradeEntryRepository;
import c7.amqp.AMQPClient;
import c7.entities.TradeEntry;
import c7.entitlement.Entitled;
import jakarta.inject.Inject;
import jakarta.jms.JMSException;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.extensions.Extension;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.ExampleObject;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

import static java.util.Collections.emptyList;

@Path("/cte")
public class TradeEntryResource {

    @Inject
    TradeEntryRepository repo;

    @Inject
    AMQPClient client;


    @GET
    @Transactional
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/list")
    @Entitled
    public String list() throws JMSException {

        StringBuilder sb = new StringBuilder();

        repo.getAllTrades().stream().forEach(t -> sb.append(t.toString()));



        return sb.toString();
    }






    @Operation(extensions = {

                    @Extension(name = "Access Type", value = "Write"),
                    @Extension(name = "Data Entity", value = "Trade"),
                    @Extension(name = "Confidentiality", value = "Critical"),
                    @Extension(name = "Data IAA", value = "Critical"),
                    @Extension(name = "Privilege1", value = "WriteFunctional"),
                    @Extension(name = "Required Privilege", value = "WriteFunctionalCritical"),
                    @Extension(name = "User", value = "Gui")
    })
    @RequestBody(content = {
                    @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Object.class),
                            examples = {
                                    @ExampleObject(name = "Enter Option Trade",
                                            value = "{\n" +
                                                    "  \"clearingHouseSymbol\": \"ECAG\",\n" +
                                                    "  \"registeredParticipant\": \"ECAG\",\n" +
                                                    "  \"userId\": \"EUREXCLR123\",  \n" +
                                                    "  \"trades\": [\n" +
                                                    "    {\n" +
                                                    "      \"basketId\": \"1234567890\",\n" +
                                                    "      \"market\": \"ECAG\",\n" +
                                                    "      \"price\": \"20.1\",\n" +
                                                    "      \"tradeType\": \"OTC_TRADE\",\n" +
                                                    "      \"instrument\": {\n" +
                                                    "        \"maturity\": \"201912\",\n" +
                                                    "        \"productSymbol\": \"ODAX\",\n" +
                                                    "        \"putCall\": \"C\",\n" +
                                                    "        \"strikePrice\": \"5000.0\"\n" +
                                                    "      },\n" +
                                                    "      \"buySide\": {\n" +
                                                    "        \"accountName\": \"A1\",\n" +
                                                    "        \"custOrdHdlInst\": \"instruction\",\n" +
                                                    "        \"openCloseIndicator\": \"C\",\n" +
                                                    "        \"ownReferenceId\": \"reference\",\n" +
                                                    "        \"owner\": \"CBKFR\",\n" +
                                                    "        \"quantity\": 1,\n" +
                                                    "        \"sponsor\": \"CBKFR\",\n" +
                                                    "        \"text1\": \"text 1\",\n" +
                                                    "        \"text2\": \"text 2\",\n" +
                                                    "        \"text3\": \"text 3\",\n" +
                                                    "        \"tradeId\": \"125\",\n" +
                                                    "        \"traderId\": \"TRD001\"\n" +
                                                    "      },\n" +
                                                    "      \"sellSide\": {\n" +
                                                    "        \"accountName\": \"A1\",\n" +
                                                    "        \"custOrdHdlInst\": \"instruction\",\n" +
                                                    "        \"openCloseIndicator\": \"C\",\n" +
                                                    "        \"ownReferenceId\": \"reference\",\n" +
                                                    "        \"owner\": \"CBKFR\",\n" +
                                                    "        \"quantity\": 1,\n" +
                                                    "        \"sponsor\": \"CBKFR\",\n" +
                                                    "        \"text1\": \"text 1\",\n" +
                                                    "        \"text2\": \"text 2\",\n" +
                                                    "        \"text3\": \"text 3\",\n" +
                                                    "        \"tradeId\": \"125\",\n" +
                                                    "        \"traderId\": \"TRD001\"\n" +
                                                    "      }\n" +
                                                    "    }\n" +
                                                    "  ]\n" +
                                                    "}}")})
            })
    @POST
    @Transactional
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/create")
    public String create( TradeEntryRequest request) {
        List<TradeRequestDetail> requestDetails = Optional.ofNullable(request.getTrades()).orElse(emptyList());
        requestDetails.stream().map(rd->createTradeEntry(request, rd)).forEach(te->
        {
            te.persist();
            try {
                client.send("Creation AMQP message",te);
            } catch (JMSException e) {
                throw new RuntimeException(e);
            }
        });

        ;
        return "Created  "+requestDetails+" to total "+repo.getAllTrades().size();
    }

    private TradeEntry createTradeEntry(TradeEntryRequest request, TradeRequestDetail tradeRequestDetail) {
        TradeEntry tradeEntry = new TradeEntry();
        tradeEntry.setClearingHouse(request.getClearingHouseSymbol());
        tradeEntry.setEnteringUser(request.getUserId());
        tradeEntry.setEnteringParticipant(request.getRegisteredParticipant());
        tradeEntry.setMarket(tradeRequestDetail.getMarket());
        tradeEntry.setPrice(tradeRequestDetail.getPrice());
        tradeEntry.setTradeType(tradeRequestDetail.getTradeType());
        tradeEntry.setInsertTime(LocalDateTime.ofInstant(Instant.now(), TimeZone.getDefault().toZoneId()));
        tradeEntry.setBasketId(tradeRequestDetail.getBasketId());
        tradeEntry.setBusinessDate(LocalDate.now());

        if (tradeRequestDetail.getBuySide() != null) {
            tradeEntry.setBuyerAccountName(tradeRequestDetail.getBuySide().getAccountName());
            tradeEntry.setBuyerSymbol(tradeRequestDetail.getBuySide().getOwner());
            tradeEntry.setBuyerOpenCloseIndicator(TradeEntry.OpenCloseIndicatorEnum.valueOf(
                    tradeRequestDetail.getBuySide().getOpenCloseIndicator()));
            tradeEntry.setBuyerQuantity(tradeRequestDetail.getBuySide().getQuantity());
            tradeEntry.setBuyerText1(tradeRequestDetail.getBuySide().getText1());
            tradeEntry.setBuyerText2(tradeRequestDetail.getBuySide().getText2());
            tradeEntry.setBuyerText3(tradeRequestDetail.getBuySide().getText3());
            tradeEntry.setBuyerSponsor(tradeRequestDetail.getBuySide().getSponsor());
            tradeEntry.setBuyerTraderId(tradeRequestDetail.getBuySide().getTraderId());
            tradeEntry.setBuyerTradeId(tradeRequestDetail.getBuySide().getTradeId());
            tradeEntry.setBuyerOwnReferenceId(tradeRequestDetail.getBuySide().getOwnReferenceId());
            tradeEntry.setBuyerCustOrdHdlInst(tradeRequestDetail.getBuySide().getCustOrdHdlInst());
        }
        if (tradeRequestDetail.getSellSide() != null) {
            tradeEntry.setSellerAccountName(tradeRequestDetail.getSellSide().getAccountName());
            tradeEntry.setSellerSymbol(tradeRequestDetail.getSellSide().getOwner());
            tradeEntry.setSellerOpenCloseIndicator(TradeEntry.OpenCloseIndicatorEnum.valueOf(
                    tradeRequestDetail.getSellSide().getOpenCloseIndicator()));
            tradeEntry.setSellerQuantity(tradeRequestDetail.getSellSide().getQuantity());
            tradeEntry.setSellerText1(tradeRequestDetail.getSellSide().getText1());
            tradeEntry.setSellerText2(tradeRequestDetail.getSellSide().getText2());
            tradeEntry.setSellerText3(tradeRequestDetail.getSellSide().getText3());
            tradeEntry.setSellerSponsor(tradeRequestDetail.getSellSide().getSponsor());
            tradeEntry.setSellerTraderId(tradeRequestDetail.getSellSide().getTraderId());
            tradeEntry.setSellerTradeId(tradeRequestDetail.getSellSide().getTradeId());
            tradeEntry.setSellerOwnReferenceId(tradeRequestDetail.getSellSide().getOwnReferenceId());
            tradeEntry.setSellerCustOrdHdlInst(tradeRequestDetail.getSellSide().getCustOrdHdlInst());
        }
        if (tradeRequestDetail.getInstrument() != null) {
            tradeEntry.setProductSymbol(tradeRequestDetail.getInstrument().getProductSymbol());
            tradeEntry.setPutCall(TradeEntry.ClassCodeEnum.valueOf(tradeRequestDetail.getInstrument().getPutCall()));
            tradeEntry.setStrikePrice(tradeRequestDetail.getInstrument().getStrikePrice());
            tradeEntry.setMaturity(tradeRequestDetail.getInstrument().getMaturity());
            tradeEntry.setContractDate(tradeRequestDetail.getInstrument().getContractDate());
            tradeEntry.setExpirationDate(tradeRequestDetail.getInstrument().getExpirationDate());
        }
        return tradeEntry;
    }









}