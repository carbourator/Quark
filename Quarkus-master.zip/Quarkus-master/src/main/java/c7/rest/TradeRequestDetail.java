package c7.rest;

import c7.entities.Instrument;
import c7.entities.Side;
import c7.entities.TradeEntry;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
public class TradeRequestDetail {


    @Schema(description = "Trade detail market symbol",
            example = "ECAG")
    private String market;
//    @Schema(description = "Trade detail price", type= SchemaType.NUMBER,
//            example = "10.3")
    private BigDecimal price;
    private Side buySide;
    private Side sellSide;
    private Instrument instrument;
    @Schema(description = "Trade detail basket id",
            example = "1234567890")
    private String basketId;

    @Schema(description = "Trade type",
            example = "OTC_TRADE")
    private TradeEntry.TradeTypeEnum tradeType;


    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }


    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Instrument getInstrument() {
        return instrument;
    }

    public void setInstrument(Instrument instrument) {
        this.instrument = instrument;
    }

    public Side getBuySide() {
        return buySide;
    }

    public void setBuySide(Side buySide) {
        this.buySide = buySide;
    }

    public Side getSellSide() {
        return sellSide;
    }

    public void setSellSide(Side sellSide) {
        this.sellSide = sellSide;
    }

    public TradeEntry.TradeTypeEnum getTradeType() {
        return tradeType;
    }

    public void setTradeType(TradeEntry.TradeTypeEnum tradeType) {
        this.tradeType = tradeType;
    }

    public String getBasketId() {
        return basketId;
    }

    public void setBasketId(String basketId) {
        this.basketId = basketId;
    }



}
