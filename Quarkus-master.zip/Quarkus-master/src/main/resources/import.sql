INSERT INTO configuration (description, insert_time, tag, value)
VALUES ('Entitlement host', NOW(), 'entitlement.host', '<entitlement.host>'),
       ('Entitlement service', NOW(), 'entitlement.service', 'entitlement/service/validationservice'),
       ('Entitlement port', NOW(), 'entitlement.port', '<entitlement.port>'),
       ('Entitlement ping service', NOW(), 'entitlement.ping.service', 'entitlement/service/ping'),
       ('Entitlement timeout (ms)', NOW(), 'entitlement.timeout',500),
       ('Cleanup retention period (days)', NOW(), 'cleanup.retention_period',5),
       ('Trade Input Gateway broker', NOW(), 'tig.broker','localhost:1425'),
       ('Trade Input Gateway queue', NOW(), 'tig.queue','broadcast/broadcast.RAPPIDD_Trade_C7TE'),
       ('Trade Input Gateway max number of retries', NOW(), 'tig.maxRetry',3),
       ('Trade Input Gateway time interval', NOW(), 'tig.timeInterval',1000),
       ('Trade Input Gateway username', NOW(), 'tig.userName','admin'),
       ('Trade Input Gateway password', NOW(), 'tig.password','admin');




